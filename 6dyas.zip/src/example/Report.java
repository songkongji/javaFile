package example;

public class Report {
	String name;
	String department;
	int korean;
	int english;
	int math;
	int tot;
	int evg;
	String res;

	public String getName() {
		return "�л� �̸� : " + name;
	}

	public String getDepartment() {
		return "�л� �а� : " + department;
	}

	public String getKorean() {
		return "�������� : " + korean;
	}

	public String getEnglish() {
		return "�������� : " + english;
	}

	public String getMath() {
		return "�������� : " + math;
	}

	public int getTot() {
		return tot = (korean + math + english);
	}

	public int getEvg() {
		return evg = tot / 3;
	}

	public String getComplete() {
		if (evg >= 60) {
			res= "�̼�";
		} else {
			res = "���̼�";
		}
		return res;
	}

	public static void main(String[] args) {
		Report person = new Report();
		person.name = "�ڸ���";
		person.department = "���а�";
		person.korean = 80;
		person.english = 70;
		person.math = 60;

		System.out.println(person.getName());
		System.out.println(person.getDepartment());
		System.out.println(person.getKorean());
		System.out.println(person.getEnglish());
		System.out.println(person.getMath());
		System.out.println("���� : " + person.getTot());
		System.out.println("��� : " + person.getEvg());
		System.out.println(person.getComplete());
		
		System.out.println();
		
		Report person2 = new Report();
		person2.name = "������";
		person2.department = "ü���а�";
		person2.korean = 100;
		person2.english = 80;
		person2.math = 80;

		System.out.println(person2.getName());
		System.out.println(person2.getDepartment());
		System.out.println(person2.getKorean());
		System.out.println(person2.getEnglish());
		System.out.println(person2.getMath());
		System.out.println("���� : " + person2.getTot());
		System.out.println("��� : " + person2.getEvg());
		System.out.println(person2.getComplete());
	}
}