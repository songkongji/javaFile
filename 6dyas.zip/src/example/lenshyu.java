package example;

public class lenshyu {

	public static void main(String[] args) {
		for(int i = 0; i < 4; i++) {
			for(int j = 1; j <= 5; j++) {
				int sum = i*5 + j;
				System.out.print(sum);
				if(sum%5 == 0) {
					System.out.println();
				}
				else {
					System.out.print(", ");
				}
			}
		}
		
		
		
//		for(int i = 1; i <= 20; i++) {
//			System.out.print(i);
//			if(i%5 == 0) {
//				System.out.println();
//			}
//			else {
//				System.out.print(", ");
//			}
//		}

	}

}
